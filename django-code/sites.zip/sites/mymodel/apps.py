from django.apps import AppConfig


class MymodelConfig(AppConfig):
    name = 'mymodel'
